// add-dice.tsx
import useMediaQuery from "@/hooks/useMediaQuery";
import AddDiceDialog from "./add-dice-dialog";
import AddDiceDrawer from "./add-dice-drawer";
import { ReactNode } from "react";

interface AddDiceProps {
    children: ReactNode;
}

const AddDice: React.FC<AddDiceProps> = ({ children }) => {
    const isDesktop = useMediaQuery("(min-width: 768px)");

    return isDesktop ? (
        <AddDiceDialog>{children}</AddDiceDialog>
    ) : (
        <AddDiceDrawer>{children}</AddDiceDrawer>
    );
};

export default AddDice;
